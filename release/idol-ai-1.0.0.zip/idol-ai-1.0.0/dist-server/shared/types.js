/**
 * IDOL AI — shared API contracts.
 *
 * These types are the single source of truth for the HTTP/SSE surface exposed by
 * the server. The browser client mirrors the shapes it consumes in
 * `web/src/types.ts`.
 */
export {};
//# sourceMappingURL=types.js.map