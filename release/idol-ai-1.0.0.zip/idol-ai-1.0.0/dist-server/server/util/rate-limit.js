export class RateLimiter {
    windowMs;
    maxRequests;
    maxKeys;
    buckets = new Map();
    constructor(windowMs, maxRequests, maxKeys = 5000) {
        this.windowMs = windowMs;
        this.maxRequests = maxRequests;
        this.maxKeys = maxKeys;
    }
    consume(key, now = Date.now()) {
        const windowStart = now - this.windowMs;
        let entries = this.buckets.get(key);
        if (!entries) {
            if (this.buckets.size >= this.maxKeys)
                this.evict(now);
            entries = [];
            this.buckets.set(key, entries);
        }
        while (entries.length > 0 && entries[0] < windowStart)
            entries.shift();
        if (entries.length >= this.maxRequests) {
            const oldest = entries[0];
            return {
                allowed: false,
                remaining: 0,
                retryAfterSeconds: Math.max(1, Math.ceil((oldest + this.windowMs - now) / 1000)),
            };
        }
        entries.push(now);
        return { allowed: true, remaining: this.maxRequests - entries.length, retryAfterSeconds: 0 };
    }
    evict(now) {
        const windowStart = now - this.windowMs;
        for (const [key, entries] of this.buckets) {
            const last = entries[entries.length - 1];
            if (last === undefined || last < windowStart)
                this.buckets.delete(key);
        }
        if (this.buckets.size >= this.maxKeys) {
            // Still full: drop the oldest insertion order entry to bound memory.
            const firstKey = this.buckets.keys().next().value;
            if (firstKey !== undefined)
                this.buckets.delete(firstKey);
        }
    }
}
//# sourceMappingURL=rate-limit.js.map