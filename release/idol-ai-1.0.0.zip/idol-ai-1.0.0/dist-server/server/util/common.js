/** Small async helpers: mutex, timeouts, retries, concurrency limiting, hashing. */
import { createHash, randomUUID } from 'node:crypto';
export function sha256(input) {
    return createHash('sha256').update(input).digest('hex');
}
export function shortHash(input, length = 10) {
    return sha256(input).slice(0, length);
}
export function newId(prefix) {
    return `${prefix}_${randomUUID().replaceAll('-', '').slice(0, 20)}`;
}
export class Mutex {
    queue = Promise.resolve();
    async run(task) {
        const previous = this.queue;
        let release;
        this.queue = new Promise((resolve) => {
            release = resolve;
        });
        await previous;
        try {
            return await task();
        }
        finally {
            release();
        }
    }
}
export function withTimeout(promise, ms, label) {
    if (ms <= 0)
        return promise;
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
        timer.unref?.();
        promise.then((value) => {
            clearTimeout(timer);
            resolve(value);
        }, (error) => {
            clearTimeout(timer);
            reject(error);
        });
    });
}
export function sleep(ms) {
    return new Promise((resolve) => {
        const timer = setTimeout(resolve, ms);
        timer.unref?.();
    });
}
export async function withRetry(task, options = {}) {
    const attempts = options.attempts ?? 3;
    const baseDelay = options.baseDelayMs ?? 300;
    const maxDelay = options.maxDelayMs ?? 4000;
    let lastError;
    for (let attempt = 0; attempt < attempts; attempt += 1) {
        try {
            return await task(attempt);
        }
        catch (error) {
            lastError = error;
            if (attempt === attempts - 1)
                break;
            options.onRetry?.(error, attempt);
            const delay = Math.min(maxDelay, baseDelay * 2 ** attempt) * (0.7 + Math.random() * 0.6);
            await sleep(delay);
        }
    }
    throw lastError;
}
export async function mapLimit(items, limit, worker) {
    const results = new Array(items.length);
    let cursor = 0;
    const size = Math.max(1, Math.min(limit, items.length || 1));
    const runners = Array.from({ length: size }, async () => {
        for (;;) {
            const index = cursor;
            cursor += 1;
            if (index >= items.length)
                return;
            const item = items[index];
            results[index] = await worker(item, index);
        }
    });
    await Promise.all(runners);
    return results;
}
/** Removes control characters and normalises whitespace for safe storage/display. */
export function sanitizeText(input) {
    return input
        .replace(/\u0000/g, '')
        .replace(/\r\n?/g, '\n')
        .replace(/[\u0001-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{4,}/g, '\n\n\n');
}
export function truncate(input, maxChars, ellipsis = '…') {
    if (input.length <= maxChars)
        return input;
    return input.slice(0, Math.max(0, maxChars - ellipsis.length)).trimEnd() + ellipsis;
}
export function clamp(value, min, max) {
    if (!Number.isFinite(value))
        return min;
    return Math.min(max, Math.max(min, value));
}
export function parseBoolean(value, fallback = false) {
    if (typeof value === 'boolean')
        return value;
    if (typeof value === 'string') {
        const lowered = value.trim().toLowerCase();
        if (['1', 'true', 'yes', 'on'].includes(lowered))
            return true;
        if (['0', 'false', 'no', 'off'].includes(lowered))
            return false;
    }
    return fallback;
}
//# sourceMappingURL=common.js.map