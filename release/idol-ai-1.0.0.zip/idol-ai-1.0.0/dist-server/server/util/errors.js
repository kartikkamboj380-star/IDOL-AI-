export class AppError extends Error {
    code;
    status;
    retryable;
    constructor(code, message, status = 400, retryable = false) {
        super(message);
        this.code = code;
        this.status = status;
        this.retryable = retryable;
        this.name = 'AppError';
    }
}
export class NotFoundError extends AppError {
    constructor(message = 'Resource not found.') {
        super('not_found', message, 404);
    }
}
export class ValidationError extends AppError {
    constructor(message) {
        super('validation_error', message, 400);
    }
}
export class PayloadTooLargeError extends AppError {
    constructor(message) {
        super('payload_too_large', message, 413);
    }
}
export class RateLimitError extends AppError {
    constructor(message, retryAfterSeconds) {
        super('rate_limited', message, 429, true);
        this.retryAfterSeconds = retryAfterSeconds;
    }
    retryAfterSeconds;
}
export class UpstreamError extends AppError {
    constructor(message, code = 'upstream_error', retryable = true) {
        super(code, message, 502, retryable);
    }
}
export class GitHubRateLimitedError extends AppError {
    resetAt;
    remaining;
    constructor(message, resetAt, remaining) {
        super('github_rate_limited', message, 429, true);
        this.resetAt = resetAt;
        this.remaining = remaining;
    }
}
export class GitHubUnauthorizedError extends AppError {
    constructor(message) {
        super('github_unauthorized', message, 401, false);
    }
}
export class MissingKnowledgeError extends AppError {
    constructor(message) {
        super('knowledge_unavailable', message, 409, false);
    }
}
export function toApiError(error) {
    if (error instanceof AppError) {
        return {
            status: error.status,
            body: { error: { code: error.code, message: error.message, retryable: error.retryable } },
        };
    }
    const message = error instanceof Error ? error.message : 'Unexpected server error.';
    return { status: 500, body: { error: { code: 'internal_error', message, retryable: true } } };
}
export function errorHandler(logger) {
    return (error, req, res, next) => {
        if (res.headersSent) {
            next(error);
            return;
        }
        const { status, body } = toApiError(error);
        if (status >= 500) {
            logger.error('request failed', {
                method: req.method,
                path: req.path,
                code: body.error.code,
                error,
            });
        }
        else {
            logger.debug('request rejected', {
                method: req.method,
                path: req.path,
                code: body.error.code,
                message: body.error.message,
            });
        }
        if (error instanceof RateLimitError)
            res.setHeader('Retry-After', String(error.retryAfterSeconds));
        res.status(status).json(body);
    };
}
export function notFoundHandler(logger) {
    return (req, res) => {
        logger.debug('no route for request', { method: req.method, path: req.path });
        const body = {
            error: { code: 'not_found', message: `No API route matches ${req.method} ${req.path}.`, retryable: false },
        };
        res.status(404).json(body);
    };
}
//# sourceMappingURL=errors.js.map