import { normalizeText } from '../knowledge/text.js';
import { isSelfDocumentation } from '../knowledge/retriever.js';
import { cleanProse, extractBullets, extractCodeBlocks, extractCommands, extractFacts, extractTables, tableCell, tidyHeading, toSentences, } from './markdown-utils.js';
const MAX_STEPS = 7;
export function composeKnowledgeAnswer(input) {
    switch (input.intent.intent) {
        case 'greeting':
            return { text: greetingAnswer(input), confidence: 'high' };
        case 'capabilities':
            return { text: capabilityAnswer(input), confidence: 'high' };
        default:
            break;
    }
    if (input.context.snippets.length === 0) {
        return { text: noEvidenceAnswer(input), confidence: 'none' };
    }
    const sections = [];
    sections.push(leadSection(input));
    switch (input.intent.intent) {
        case 'how_to':
            sections.push(...howToSections(input));
            break;
        case 'code_explanation':
            sections.push(...codeSections(input));
            break;
        case 'bug_analysis':
        case 'troubleshooting':
            sections.push(...troubleshootingSections(input));
            break;
        case 'summarization':
            sections.push(...summarySections(input));
            break;
        case 'comparison':
            sections.push(...comparisonSections(input));
            break;
        case 'documentation_search':
            sections.push(...documentationSections(input));
            break;
        case 'repo_overview':
            sections.push(...overviewSections(input));
            break;
        default:
            sections.push(...detailSections(input));
    }
    const tables = extractTables(input.context.snippets.map((snippet) => snippet.text).join('\n\n'));
    if (tables.length > 0 && ['comparison', 'factual_lookup', 'documentation_search'].includes(input.intent.intent)) {
        const table = tables[0];
        const owner = input.context.snippets.find((snippet) => snippet.text.includes(table.headers.join(' | ')) || snippet.text.includes(`| ${table.headers[0]}`));
        sections.push(renderTable(table, owner?.id ?? input.context.snippets[0]?.id));
    }
    const coverage = coverageNote(input);
    if (coverage)
        sections.push(coverage);
    sections.push(provenanceFooter(input));
    return {
        text: sections.filter((section) => section.trim().length > 0).join('\n\n'),
        confidence: scoreConfidence(input),
    };
}
/* ------------------------------------------------------------------ */
/* Lead + structural sections                                          */
/* ------------------------------------------------------------------ */
/** One or two clean, quoted sentences that directly address the question. */
/**
 * Picks the passage that should open the answer.
 *
 * Ranking order is a guide, not the answer: a passage can score highest because
 * its *table* repeats the query word while its prose talks about something else
 * (asking "how much VRAM" surfaces a GPU table whose lead sentence is about
 * request time). So the opening passage must have the question's own vocabulary
 * in its prose. When no passage does, the highest-ranked one is still used —
 * and the answer says what it actually found.
 */
function chooseLeadSnippet(ranked, analysis) {
    if (ranked.length === 0)
        return null;
    // A descriptive question ("what is this project?") is answered by descriptive
    // prose, even if another passage shares more keywords with the question.
    const descriptive = ranked.filter((snippet) => isDescriptionPassage(snippet.text));
    if (descriptive.length > 0 && /\b(what is (this|it|the (repo|repository|project))|about|overview|summary|summar(y|ise|ize)|purpose)\b/i.test(analysis.raw)) {
        return descriptive[0] ?? ranked[0] ?? null;
    }
    const terms = analysis.terms.filter((term) => term.length > 2);
    if (terms.length === 0)
        return ranked[0] ?? null;
    for (const snippet of ranked.slice(0, 4)) {
        const haystack = normalizeText(snippet.text);
        const overlap = terms.filter((term) => haystack.includes(term)).length;
        if (overlap > 0)
            return snippet;
    }
    return ranked[0] ?? null;
}
function leadSection(input) {
    // Trust the retriever's ranking for the opening passage. Re-ranking here is
    // how a passage that merely *mentions* the question's words ("the VRAM figure
    // is an example") ends up ahead of the table that actually answers it. The
    // retriever already applies document weights, code/data penalties, phrase
    // bonuses and the self-documentation prior; this stage must not second-guess it.
    const top = input.context.snippets[0];
    if (!top)
        return '';
    const location = `${top.path}${top.heading ? ` › ${tidyHeading(top.heading)}` : ''}`;
    const hasTable = /^\s*\|.+\|/m.test(top.text) && /^\s*\|[-: |]+\|/m.test(top.text);
    if (top.kind !== 'code') {
        const sentences = pickBestSentences(top.text, input.analysis, 2);
        if (sentences.length > 0) {
            return `${sentences.join(' ')} [${top.id}]\n\n*Source: \`${location}\`, lines ${top.startLine}–${top.endLine}.*`;
        }
    }
    // No prose to quote. Say precisely what the passage is, so the reader knows
    // why the answer continues below instead of pretending a sentence was found.
    if (hasTable) {
        return `The figures are in the table at **${location}** (lines ${top.startLine}–${top.endLine}) [${top.id}], reproduced below.`;
    }
    if (top.kind === 'code') {
        return `The most relevant passage is **${location}** (lines ${top.startLine}–${top.endLine}) [${top.id}], which is source code — the excerpts below quote it exactly.`;
    }
    return `The most relevant passage is **${location}** (lines ${top.startLine}–${top.endLine}) [${top.id}]; the excerpts below quote it exactly.`;
}
function howToSections(input) {
    const sections = [];
    const commands = new Map();
    for (const snippet of input.context.snippets) {
        for (const command of extractCommands(snippet.text))
            commands.set(command, snippet.id);
    }
    if (commands.size > 0) {
        const lines = [...commands.entries()].slice(0, 8).map(([command, id]) => `${command}   # [${id}]`);
        sections.push(`**Commands from the source**\n\n\`\`\`bash\n${lines.join('\n')}\n\`\`\``);
    }
    const steps = buildSteps(input);
    if (steps.length > 0) {
        sections.push(`**Sequence described in the documentation**\n\n${steps.map((step, index) => `${index + 1}. ${step}`).join('\n')}`);
    }
    else {
        const bullets = collectBullets(input, 5);
        if (bullets.length > 0) {
            sections.push(`**Key points that govern these instructions**\n\n${bullets.map((bullet) => `- ${bullet.text} [${bullet.id}]`).join('\n')}`);
        }
    }
    const constraints = collectConstraints(input, 3);
    if (constraints.length > 0) {
        sections.push(`**Requirements and caveats stated in the sources**\n\n${constraints.map((item) => `- ${item.text} [${item.id}]`).join('\n')}`);
    }
    return sections;
}
function buildSteps(input) {
    const steps = [];
    const seen = new Set();
    for (const snippet of proseSnippets(input)) {
        // Numbered lists and bold step headings are the strongest step signal.
        const lines = snippet.text.split('\n');
        let inFence = false;
        for (const rawLine of lines) {
            const line = rawLine.trim();
            if (/^```/.test(line)) {
                inFence = !inFence;
                continue;
            }
            if (inFence)
                continue;
            const numbered = /^(\d+)[.)]\s+(.{10,260})$/.exec(line);
            const boldStep = /^\*\*(\d+[.)])?\s*([^*]{6,120})\*\*\s*$/.exec(line);
            const heading = /^#{2,4}\s+(.{4,120})$/.exec(line);
            let text = null;
            if (numbered?.[2])
                text = numbered[2];
            else if (boldStep?.[2])
                text = boldStep[2];
            else if (heading?.[1])
                text = heading[1];
            if (!text)
                continue;
            const cleaned = stripInlineMarkup(text);
            if (cleaned.length < 8)
                continue;
            if (/^(examples?|get started|install|usage|flags|benchmark|across gpus|more details|faq|license|contents|table of contents)$/i.test(cleaned)) {
                continue;
            }
            if (/^name:/i.test(cleaned))
                continue; // GitHub Actions step names are not user steps
            const key = cleaned.toLowerCase().slice(0, 40);
            if (seen.has(key))
                continue;
            seen.add(key);
            steps.push(`${cleaned} [${snippet.id}]`);
            if (steps.length >= MAX_STEPS)
                return steps;
            break; // one step per snippet keeps citations honest and varied
        }
    }
    return steps;
}
function codeSections(input) {
    const sections = [];
    const codeSnippets = input.context.snippets.filter((snippet) => snippet.kind === 'code');
    const shown = (codeSnippets.length > 0 ? codeSnippets : input.context.snippets).slice(0, 2);
    for (const snippet of shown) {
        const lines = snippet.text.split('\n').slice(0, 22);
        const start = snippet.startLine;
        const language = snippet.language || 'text';
        sections.push(`**\`${snippet.path}\` — lines ${start}–${start + lines.length - 1}** [${snippet.id}]\n\n\`\`\`${language}\n${lines.join('\n')}\n\`\`\``);
    }
    const explained = codeSnippets[0] ?? input.context.snippets[0];
    if (explained) {
        const facts = extractFacts(explained.text).slice(0, 4);
        const commands = extractCommands(explained.text).slice(0, 3);
        const notes = [];
        for (const fact of facts)
            notes.push(`- **${fact.label}**: ${fact.value} [${explained.id}]`);
        for (const command of commands)
            notes.push(`- Runs \`${command}\` [${explained.id}]`);
        if (notes.length > 0)
            sections.push(`**What the retrieved code shows**\n\n${notes.join('\n')}`);
    }
    return sections;
}
function troubleshootingSections(input) {
    const sections = [];
    const warnings = collectConstraints(input, 5);
    if (warnings.length > 0) {
        sections.push(`**Constraints and failure conditions the sources state**\n\n${warnings.map((item) => `- ${item.text} [${item.id}]`).join('\n')}`);
    }
    const commands = new Map();
    for (const snippet of input.context.snippets) {
        for (const command of extractCommands(snippet.text))
            commands.set(command, snippet.id);
    }
    if (commands.size > 0) {
        sections.push(`**Commands referenced in the relevant passages**\n\n\`\`\`bash\n${[...commands.entries()]
            .slice(0, 6)
            .map(([command, id]) => `${command}   # [${id}]`)
            .join('\n')}\n\`\`\``);
    }
    if (sections.length === 0)
        return detailSections(input);
    return sections;
}
/** Heuristic: does this passage actually describe the project? */
function isDescriptionPassage(text) {
    return /\b(turns?|is a|is an|provides?|generates?|enables?|allows?|built|designed (to|for)|aims? to)\b/i.test(text);
}
function summarySections(input) {
    const bullets = [];
    const seen = new Set();
    // Put description-like passages first: a summary should open with what the
    // project is, not with its installation steps.
    const ordered = proseSnippets(input)
        .slice()
        .sort((a, b) => Number(isDescriptionPassage(b.text)) - Number(isDescriptionPassage(a.text)));
    for (const snippet of onTopicSnippets(ordered)) {
        const label = tidyHeading(snippet.heading ?? snippet.path.split('/').pop() ?? snippet.path);
        const sentence = pickBestSentences(snippet.text, input.analysis, 1)[0];
        const bullet = sentence ?? extractBullets(snippet.text)[0];
        if (!bullet)
            continue;
        const key = bullet.toLowerCase().slice(0, 48);
        if (seen.has(key))
            continue;
        seen.add(key);
        bullets.push(`- **${label}** — ${bullet} [${snippet.id}]`);
        if (bullets.length >= 6)
            break;
    }
    if (bullets.length === 0)
        return detailSections(input);
    return [`**What the indexed sources say**\n\n${bullets.join('\n')}`];
}
function comparisonSections(input) {
    const rows = [];
    for (const snippet of proseSnippets(input).slice(0, 5)) {
        const statement = pickBestSentences(snippet.text, input.analysis, 1)[0] ?? extractBullets(snippet.text)[0];
        if (!statement)
            continue;
        rows.push(`| ${tableCell(statement)} | \`${snippet.path}\`${snippet.heading ? ` › ${tableCell(snippet.heading, 60)}` : ''} | [${snippet.id}] |`);
    }
    if (rows.length === 0)
        return detailSections(input);
    return [
        `**Passage-by-passage comparison**\n\n| Passage says | Location | Citation |\n|---|---|---|\n${rows.join('\n')}`,
        `This table only reports what each retrieved passage states. Any comparison the sources do not make is deliberately left out.`,
    ];
}
function documentationSections(input) {
    const bySource = new Map();
    for (const snippet of onTopicSnippets(proseSnippets(input))) {
        const list = bySource.get(snippet.sourceName) ?? [];
        list.push(snippet);
        bySource.set(snippet.sourceName, list);
    }
    const parts = [];
    for (const [sourceName, snippets] of bySource) {
        const items = snippets.slice(0, 6).map((snippet) => {
            const where = `${snippet.path}${snippet.heading ? ` › ${snippet.heading}` : ''}`;
            const gist = pickBestSentences(snippet.text, input.analysis, 1)[0];
            return `- \`${where}\` (lines ${snippet.startLine}–${snippet.endLine}) [${snippet.id}]${gist ? ` — ${gist}` : ''}`;
        });
        parts.push(`**${sourceName}**\n\n${items.join('\n')}`);
    }
    return [`**Where this appears**\n\n${parts.join('\n\n')}`];
}
function overviewSections(input) {
    // "What is this?" is answered by descriptive prose. Put description-like
    // passages first so the body of the answer is about the product, not about
    // installation mechanics that happen to share the question's vocabulary.
    const ranked = proseSnippets(input)
        .slice()
        .sort((a, b) => Number(isDescriptionPassage(b.text)) - Number(isDescriptionPassage(a.text)));
    const lead = chooseLeadSnippet(proseSnippets(input), input.analysis);
    const leadText = lead ? normalizeText(pickBestSentences(lead.text, input.analysis, 2).join(' ')) : '';
    const paragraphs = [];
    for (const snippet of ranked.slice(0, 3)) {
        const sentences = pickBestSentences(snippet.text, input.analysis, 2).filter((sentence) => !(leadText.length > 0 && leadText.includes(normalizeText(sentence))));
        if (sentences.length === 0)
            continue;
        paragraphs.push(`${sentences.join(' ')} [${snippet.id}]`);
    }
    const structure = ranked.slice(0, 6).map((snippet) => {
        const where = `\`${snippet.path}\`${snippet.heading ? ` › ${tidyHeading(snippet.heading)}` : ''}`;
        return `- ${where} — lines ${snippet.startLine}–${snippet.endLine} [${snippet.id}]`;
    });
    const bullets = collectBullets(input, 4);
    const parts = [];
    if (paragraphs.length > 0)
        parts.push(`**What the documentation says**\n\n${paragraphs.join('\n\n')}`);
    if (bullets.length > 0)
        parts.push(`**Highlights**\n\n${bullets.map((bullet) => `- ${bullet.text} [${bullet.id}]`).join('\n')}`);
    if (structure.length > 0)
        parts.push(`**Relevant passages**\n\n${structure.join('\n')}`);
    return parts;
}
function detailSections(input) {
    const leadText = normalizeText(pickBestSentences((chooseLeadSnippet(proseSnippets(input), input.analysis) ?? input.context.snippets[0]).text, input.analysis, 2).join(' '));
    const bullets = [];
    const seen = new Set();
    // Put description-like passages first: a summary should open with what the
    // project is, not with its installation steps.
    const ordered = proseSnippets(input)
        .slice()
        .sort((a, b) => Number(isDescriptionPassage(b.text)) - Number(isDescriptionPassage(a.text)));
    for (const snippet of onTopicSnippets(ordered)) {
        for (const sentence of pickBestSentences(snippet.text, input.analysis, 2)) {
            const key = sentence.toLowerCase().slice(0, 40);
            if (seen.has(key))
                continue;
            // Never restate the opening sentence as a bullet.
            if (leadText.length > 0 && leadText.includes(normalizeText(sentence)))
                continue;
            seen.add(key);
            bullets.push(`- ${sentence} [${snippet.id}]`);
            if (bullets.length >= 4)
                break;
        }
        if (bullets.length >= 4)
            break;
    }
    if (bullets.length > 0)
        return [`**What the sources say**\n\n${bullets.join('\n')}`];
    // Fallback 1: any prose paragraph at all, even if it does not match keywords —
    // but still only from passages that are on topic.
    for (const snippet of onTopicSnippets(input.context.snippets)) {
        const paragraphs = cleanProse(snippet.text)
            .split('\n')
            .map((line) => line.trim())
            .filter((line) => line.length > 60);
        const paragraph = paragraphs[0];
        if (paragraph && !looksLikeData(paragraph)) {
            return [`**From \`${snippet.path}\`**${snippet.heading ? ` › ${snippet.heading}` : ''} [${snippet.id}]\n\n> ${paragraph}`];
        }
    }
    // Fallback 2: real code evidence, quoted exactly, never paraphrased.
    const codeSnippet = input.context.snippets.find((snippet) => snippet.kind === 'code') ?? input.context.snippets[0];
    if (!codeSnippet)
        return ['No usable passage was retrieved.'];
    return [
        `**Relevant excerpt from \`${codeSnippet.path}\`** [${codeSnippet.id}]\n\n\`\`\`${codeSnippet.language}\n${codeSnippet.text
            .split('\n')
            .slice(0, 16)
            .join('\n')}\n\`\`\``,
    ];
}
/* ------------------------------------------------------------------ */
/* Static responses                                                    */
/* ------------------------------------------------------------------ */
function greetingAnswer(input) {
    const corpus = input.corpus;
    const suggestions = [
        'What is this repository about?',
        'How do I install and run it?',
        'Summarise the README',
        'What are the hardware requirements?',
    ];
    return [
        `Hello — I'm **IDOL AI**. I answer questions using only the knowledge indexed in this workspace, and I cite the exact file, heading, and line range behind every claim.`,
        corpus.passages > 0
            ? `Right now I can search **${corpus.passages.toLocaleString()} passages** from **${corpus.files.toLocaleString()} files** across **${corpus.sources} source(s)**.`
            : `No knowledge source is indexed yet. Open **Sources** to index a repository, then ask me anything about it.`,
        `Some things to try:\n\n${suggestions.map((suggestion) => `- ${suggestion}`).join('\n')}`,
    ].join('\n\n');
}
function capabilityAnswer(input) {
    const can = [
        'Search every indexed file (docs, source code, config, notebooks) with BM25 ranking and field boosts',
        'Answer with exact citations — file path, heading, and line range for each claim',
        'Explain retrieved code and list static observations (symbols, imports, risky patterns)',
        'Summarise documents, compare passages, and walk through documented procedures',
        'Use earlier turns in the conversation when a follow-up question is vague',
        'Say "I could not find that" instead of inventing an answer',
    ];
    const cannot = [
        'Answer from general world knowledge outside the indexed repositories',
        'Claim a file was read when it was skipped (binaries, LFS pointers, oversized files)',
        'Behave like a large language model when no inference provider is configured',
    ];
    const modeLine = input.mode === 'inference'
        ? `**Current mode: inference.** Model answers are generated by \`${input.inferenceNote ?? 'the configured provider'}\` and grounded in retrieved passages; citations are validated before display.`
        : `**Current mode: knowledge.** Answers are composed by an extractive summariser over retrieved passages. No language model is used, so wording comes from your repository.`;
    return [
        `I'm **IDOL AI**, a retrieval-grounded assistant for repository knowledge.`,
        `${modeLine}\n\nIndexed corpus: **${input.corpus.passages.toLocaleString()} passages** from **${input.corpus.files.toLocaleString()} files** in **${input.corpus.sources} source(s)**.`,
        `**What I can do**\n\n${can.map((item) => `- ${item}`).join('\n')}`,
        `**What I cannot do**\n\n${cannot.map((item) => `- ${item}`).join('\n')}`,
    ].join('\n\n');
}
function noEvidenceAnswer(input) {
    const lines = [`I could not find anything in the indexed knowledge that answers this, so I won't guess.`];
    if (input.corpus.passages === 0) {
        lines.push('No knowledge source is indexed yet. Add a repository under **Sources** and index it first — there is nothing to search until then.');
    }
    else {
        const searched = input.coverage.missing.filter((term) => term.length > 4).slice(0, 5);
        lines.push(`I searched ${input.corpus.passages.toLocaleString()} passages across ${input.corpus.files.toLocaleString()} files${searched.length > 0 ? ` for ${searched.map((term) => `\`${term}\``).join(', ')}` : ''} and found no passage above the relevance threshold.`);
    }
    lines.push(`**Ways to get an answer**\n\n- Rephrase using words that appear in the repository (file names, config keys, CLI flags)\n- Ask about a specific file, e.g. \`huggingface/speridlabs-idol/README.md\`\n- Add or re-index a source that covers the topic`);
    return lines.join('\n\n');
}
/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
/**
 * Ranks snippets by question-term overlap, with a strong prose preference for
 * documentation questions. Code passages stay available for code intents but
 * never masquerade as explanatory prose.
 */
function rankSnippetsForQuestion(input) {
    const terms = input.analysis.terms.filter((term) => term.length > 2);
    const codeIntent = input.intent.intent === 'code_explanation' || input.intent.intent === 'bug_analysis';
    // "What is this project?" questions are answered by a README's opening
    // description, which rarely repeats the question's words — so give the
    // document opening an explicit prior for overview/summary intents.
    const overviewIntent = input.intent.intent === 'repo_overview' || input.intent.intent === 'summarization';
    return [...input.context.snippets]
        .filter((snippet) => !/^front matter$/i.test(snippet.heading ?? ''))
        .map((snippet) => {
        const haystack = normalizeText(`${snippet.heading ?? ''} ${snippet.text}`);
        const overlap = terms.filter((term) => haystack.includes(term)).length;
        const kindBonus = snippet.kind === 'code' ? (codeIntent ? 2 : -14) : snippet.kind === 'markdown' ? 6 : 0;
        const isOpening = /(^|\/)readme\.md$/i.test(snippet.path) && snippet.startLine <= 40;
        const openingBonus = overviewIntent && isOpening ? 22 : 0;
        return { snippet, rank: overlap * 10 + snippet.score / 10 + kindBonus + openingBonus };
    })
        .sort((a, b) => b.rank - a.rank)
        .map((entry) => entry.snippet);
}
/**
 * Prose snippets only. A passage indexed as markdown can still be a table row
 * or a config blob, so this also rejects passages that read like data.
 */
/**
 * Passages worth quoting in the body of an answer: those that scored at least
 * 45% of the best hit. Weaker matches usually share one word with the question
 * (the app's own notes matching "run"/"hardware") and quoting them buries the
 * real answer under unrelated material.
 */
function onTopicSnippets(snippets) {
    const topScore = Math.max(0, ...snippets.map((snippet) => snippet.score));
    // When the best evidence comes from the project's own docs, the app's docs may
    // speak too (someone asking "how do I run the tests?" needs docs/ARCHITECTURE.md).
    // When it comes from the indexed corpus, they are background noise: they earned
    // their retrieval score on shared vocabulary, not on answering the question.
    const leadIsSelfDoc = snippets[0] !== undefined && isSelfDocumentation(snippets[0].path);
    const relevant = snippets.filter((snippet) => {
        if (topScore > 0 && snippet.score < topScore * 0.45)
            return false;
        if (!leadIsSelfDoc && isSelfDocumentation(snippet.path))
            return false;
        return true;
    });
    return relevant.length > 0 ? relevant : snippets.slice(0, 1);
}
function proseSnippets(input) {
    return rankSnippetsForQuestion(input).filter((snippet) => snippet.kind !== 'code' && snippet.kind !== 'data' && !looksLikeData(snippet.text));
}
/** True when a line is basically a path, slug, model id, or config token. */
function looksLikeIdentifier(text) {
    const trimmed = text.trim();
    if (/^[\w.-]+\/[\w.-]+$/.test(trimmed))
        return true; // owner/repo, org/model
    if (/^[\w.-]+(__[\w.-]+)+$/.test(trimmed))
        return true; // some__python__package
    if (/^[\x60'"`][^\s]+[\x60'"`]$/.test(trimmed))
        return true; // fully quoted token
    const words = trimmed.split(/\s+/);
    const spaceless = words.filter((word) => !/[\s]/.test(word) && /[/_.:]/.test(word)).length;
    return words.length <= 3 && spaceless >= 1;
}
/** Heuristic: too much JSON/punctuation density means it is not prose. */
function looksLikeData(text) {
    // Markdown files legitimately carry HTML in hero sections (<p align="center">,
    // <h1>, <img>). Strip tags before measuring punctuation density, or a perfectly
    // good product description is misread as a config blob.
    const trimmed = text.replace(/<[^>]{1,400}>/g, ' ').trim();
    if (/^[{[]/.test(trimmed))
        return true;
    const tableRows = trimmed.split('\n').filter((line) => line.trim().startsWith('|')).length;
    const nonEmpty = trimmed.split('\n').filter((line) => line.trim().length > 0).length;
    if (nonEmpty > 0 && tableRows / nonEmpty > 0.6)
        return true;
    const punctuation = (trimmed.match(/[{}[\]":=<>;]/g) ?? []).length;
    return punctuation / Math.max(1, trimmed.length) > 0.07;
}
/** Sentence selection: term overlap first, position second, noise filtered. */
function pickBestSentences(text, analysis, count) {
    const sentences = toSentences(text);
    if (sentences.length === 0)
        return [];
    const terms = analysis.terms.filter((term) => term.length > 2);
    const quantitative = /\b(how (much|many|long|fast|big)|cost|price|size|count|number of|how large)\b/i.test(analysis.raw);
    const scored = sentences.map((sentence, index) => {
        const normalized = normalizeText(sentence);
        let score = 0;
        for (const term of terms)
            if (normalized.includes(term))
                score += 1;
        if (/\b(is|are|means|refers to|requires?|supports?|includes?|allows?|generates?|removes?|runs?)\b/i.test(sentence))
            score += 0.4;
        score += Math.max(0, 0.5 - index * 0.06);
        if (sentence.length > 420)
            score -= 0.5;
        if (/https?:\/\//.test(sentence))
            score -= 0.3;
        // Table/figure captions are legend text, not an answer: "Bold is the best in
        // each column", "Numbers are medians", asterisk footnotes. They must never
        // become the opening sentence.
        if (/^(bold|italic|numbers?|values?|figures?|\*|†|‡|results? are|all (numbers|values|times))/i.test(sentence))
            score -= 2.5;
        if (/\b(each column|each row|highest .+ despite|medians? over|average of \d+ (runs|images))\b/i.test(sentence))
            score -= 1.5;
        if (sentence.length < 25)
            score -= 0.6;
        // "How much VRAM / how many steps / at what cost" — a sentence without a
        // number cannot be the answer to a quantitative question.
        if (quantitative) {
            if (/[\d]/.test(sentence))
                score += 0.9;
            else
                score -= 1.2;
        }
        return { sentence, score, index };
    });
    return scored
        .filter((entry) => entry.score > 0.35)
        .sort((a, b) => b.score - a.score)
        .slice(0, count)
        .sort((a, b) => a.index - b.index)
        .map((entry) => entry.sentence);
}
function collectBullets(input, limit) {
    const out = [];
    const terms = input.analysis.terms.filter((term) => term.length > 2);
    for (const snippet of proseSnippets(input)) {
        for (const bullet of extractBullets(snippet.text)) {
            // A bullet that is really an identifier or a checklist marker ("- [ ]
            // facebook/dinov3-…") is not a highlight a reader can use.
            if (looksLikeIdentifier(bullet) || /^\[.\]/.test(bullet))
                continue;
            if (bullet.split(' ').length < 4)
                continue;
            const normalized = normalizeText(bullet);
            const overlap = terms.filter((term) => normalized.includes(term)).length;
            if (overlap === 0 && out.length >= 2)
                continue;
            out.push({ text: bullet, id: snippet.id });
            if (out.length >= limit)
                return out;
        }
    }
    return out;
}
function collectConstraints(input, limit) {
    const patterns = [
        /\b(requires?|required|must|only|needs?|prerequisites?|must be|before|note that|ensure|at least|maximum|minimum|not supported|does not|doesn't|cannot)\b/i,
        /\b(memory|vram|gpu|cuda|python|version|licen[cs]e|token|quota|limit)\b/i,
    ];
    const out = [];
    const seen = new Set();
    for (const snippet of proseSnippets(input)) {
        for (const sentence of toSentences(snippet.text)) {
            if (!patterns.some((pattern) => pattern.test(sentence)))
                continue;
            const key = sentence.toLowerCase().slice(0, 44);
            if (seen.has(key))
                continue;
            seen.add(key);
            out.push({ text: sentence, id: snippet.id });
            if (out.length >= limit)
                return out;
        }
    }
    return out;
}
function renderTable(table, citationId) {
    const headers = table.headers.map((header) => tableCell(header, 40));
    const rows = table.rows.slice(0, 12).map((row) => {
        const cells = [];
        for (let index = 0; index < headers.length; index += 1)
            cells.push(tableCell(row[index] ?? '', 48));
        return `| ${cells.join(' | ')} |`;
    });
    const caption = table.caption ? `${table.caption} [${citationId}]\n\n` : '';
    return `**Table from the source** [${citationId}]\n\n${caption}| ${headers.join(' | ')} |\n|${headers.map(() => '---').join('|')}|\n${rows.join('\n')}`;
}
function coverageNote(input) {
    const missing = input.coverage.missing.filter((term) => term.length > 3).slice(0, 6);
    if (missing.length === 0)
        return '';
    return `> **Not found in the indexed sources:** ${missing.map((term) => `\`${term}\``).join(', ')}. Those parts of the question were left unanswered rather than guessed.`;
}
function provenanceFooter(input) {
    if (input.mode === 'inference') {
        return `---\n\n*Generated by ${input.inferenceNote ?? 'the configured inference provider'}, grounded in ${input.context.snippets.length} retrieved passage(s). Every citation was checked against the retrieved text.*`;
    }
    return `---\n\n*Knowledge mode — extractive summary of ${input.context.snippets.length} retrieved passage(s). No language model was used; wording comes from the sources and citations are exact.*`;
}
function scoreConfidence(input) {
    const top = input.context.snippets[0];
    if (!top)
        return 'none';
    const coverage = input.coverage.matched.length / Math.max(1, input.coverage.matched.length + input.coverage.missing.length);
    if (top.score > 8 && coverage > 0.55 && input.context.snippets.length >= 2)
        return 'high';
    if (top.score > 3.5 && coverage > 0.3)
        return 'medium';
    return 'low';
}
/** Removes bold/italic/code markers but keeps wording for inline sentences. */
function stripInlineMarkup(text) {
    return text
        .replace(/\*\*([^*]+)\*\*/g, '$1')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/^\d+[.)]\s*/, '')
        .replace(/\s{2,}/g, ' ')
        .trim();
}
/** Terms from the question that never appeared in retrieved passages. */
export function computeCoverage(analysis, snippets, ignore = []) {
    const corpus = normalizeText(snippets.map((snippet) => snippet.text).join(' '));
    const matched = [];
    const missing = [];
    const ignored = new Set(ignore.map((term) => normalizeText(term)));
    for (const term of analysis.terms) {
        if (term.length < 3)
            continue;
        // Filename words ("readme") and request verbs ("summarise") are directives,
        // not facts to verify against the passages.
        if ([...ignored].some((entry) => entry.includes(term) || term.includes(entry)))
            continue;
        if (['summaris', 'summariz', 'summari', 'readm', 'changelog'].some((stop) => term.startsWith(stop)))
            continue;
        if (corpus.includes(term))
            matched.push(term);
        else
            missing.push(term);
    }
    return { matched, missing: missing.sort((a, b) => b.length - a.length).slice(0, 8) };
}
export { extractCodeBlocks };
//# sourceMappingURL=answer-composer.js.map