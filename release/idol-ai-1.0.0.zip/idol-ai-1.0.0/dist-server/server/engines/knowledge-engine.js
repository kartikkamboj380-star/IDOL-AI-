import { analyzeQuestion, detectFileTargets } from './question-analyzer.js';
import { expandQuery } from './expansion.js';
import { detectIntent } from './intent.js';
import { buildContext } from './context-builder.js';
import { aggregateFindings, analyzePassage } from './code-analysis.js';
import { computeCoverage } from './answer-composer.js';
import { contentTerms } from '../knowledge/text.js';
export class KnowledgeEngine {
    logger;
    knowledge;
    retriever;
    constructor(logger, knowledge, retriever) {
        this.logger = logger;
        this.knowledge = knowledge;
        this.retriever = retriever;
    }
    /** Number of passages available to search, for status display. */
    corpus() {
        const stats = this.knowledge.stats();
        return {
            passages: this.knowledge.totalPassages(),
            files: stats.totalFiles,
            sources: stats.readySources,
        };
    }
    /** Step 1 of the engine, exposed separately so memory can run in between. */
    understand(question, priorTerms) {
        const analysis = analyzeQuestion(question, { priorTerms: priorTerms?.slice(-40) });
        return { analysis, intent: detectIntent(analysis) };
    }
    /**
     * Builds the evidence set for one question. Pure with respect to the app: it
     * reads indexes and returns data, so it can be unit-tested without a server.
     */
    gather(input) {
        const started = Date.now();
        /* 1 — Understand the question -------------------------------------- */
        const t1 = Date.now();
        const analysis = input.analysis ?? analyzeQuestion(input.question, { priorTerms: input.priorTerms?.slice(-40) });
        const intent = input.intent ?? detectIntent(analysis);
        const analyzeMs = Date.now() - t1;
        /* 2 — Decide what to search ---------------------------------------- */
        const t2 = Date.now();
        const preferCode = intent.intent === 'code_explanation' || intent.intent === 'bug_analysis';
        // "Summarise the README" names a file, not a topic: restrict retrieval to
        // matching paths and drop the filename word from the keyword query.
        const pathTargets = detectFileTargets(analysis.normalized);
        const retrievalTerms = pathTargets.length > 0
            ? analysis.terms.filter((term) => !pathTargets.some((target) => target.startsWith(term) || term.startsWith(target)))
            : analysis.terms;
        const expansion = intent.intent === 'out_of_scope' ? { terms: [], concepts: [] } : expandQuery(retrievalTerms, 12);
        const retrievalQuery = pathTargets.length > 0 ? retrievalTerms.join(' ') || analysis.normalized : retrievalTerms.join(' ') || analysis.normalized;
        /* 3 — Search every ready source ------------------------------------ */
        const retrieval = this.retriever.retrieve(retrievalQuery, {
            topK: intent.intent === 'summarization' ? 10 : 8,
            sourceIds: input.sourceIds,
            preferDocs: !preferCode,
            preferCode,
            expansionTerms: expansion.terms,
            pathTargets,
            intent: intent.intent,
        });
        const searchMs = Date.now() - t2;
        /* 4 — Keep only real evidence -------------------------------------- */
        const t3 = Date.now();
        const conversational = intent.intent === 'greeting' || intent.intent === 'capabilities';
        const topScore = retrieval.hits[0]?.score ?? 0;
        // A hit must clear an absolute floor and stay within reach of the best hit,
        // otherwise it is noise and must not be shown as a source.
        const floor = conversational ? Number.POSITIVE_INFINITY : Math.max(0.9, topScore * 0.18);
        const relevantHits = retrieval.hits.filter((hit) => hit.score >= floor);
        // Hard evidence guard: lexical matching can score "the", numbers, or expansion
        // terms, none of which proves the corpus covers the question. If none of the
        // question's own content terms appear in any retrieved passage, there is no
        // evidence and the answer must say so rather than quote something unrelated.
        const questionTerms = new Set([...analysis.terms, ...contentTerms(input.question).terms]);
        const lexicalEvidence = relevantHits.some((hit) => {
            const haystack = `${hit.path} ${hit.passage.heading ?? ''} ${hit.passage.text}`.toLowerCase();
            return [...questionTerms].some((term) => term.length > 2 && haystack.includes(term));
        });
        const grounded = conversational || lexicalEvidence;
        if (!grounded)
            relevantHits.length = 0;
        const context = buildContext({
            hits: relevantHits.map((hit) => {
                const index = this.knowledge.getIndex(hit.sourceId);
                const source = this.knowledge.listSources().find((item) => item.id === hit.sourceId);
                return {
                    passage: hit.passage,
                    score: hit.score,
                    sourceName: source?.name ?? hit.sourceId,
                    htmlUrl: index ? hit.htmlUrl : null,
                };
            }),
            maxChars: input.maxChars ?? 12000,
            maxSnippets: input.maxSnippets ?? 6,
            maxPerFile: 3,
            minRelativeScore: 0,
        });
        const codeFindings = aggregateFindings(relevantHits.slice(0, 6).flatMap((hit) => analyzePassage(hit.passage)));
        const coverage = computeCoverage(analysis, context.snippets, pathTargets);
        const rankMs = Date.now() - t3;
        this.logger.debug('knowledge engine gathered evidence', {
            candidates: retrieval.hits.length,
            kept: context.snippets.length,
            grounded,
            sources: context.sources.length,
        });
        return {
            analysis,
            intent,
            expansion,
            retrievalQuery,
            context,
            candidates: retrieval.hits.length,
            discarded: retrieval.hits.length - context.snippets.length,
            grounded,
            codeFindings,
            coverage,
            pathTargets,
            sources: context.sources,
            timings: { analyze: analyzeMs, search: searchMs, rank: rankMs },
        };
    }
    /** Total time the engine spent, for the answer's timing report. */
    static elapsed(result, startedAt) {
        void result;
        return Date.now() - startedAt;
    }
}
//# sourceMappingURL=knowledge-engine.js.map