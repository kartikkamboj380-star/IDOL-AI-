import { composeKnowledgeAnswer } from './answer-composer.js';
import { validateAnswer } from './validator.js';
import { InferenceError } from '../inference/provider.js';
import { newId } from '../util/common.js';
export class AnswerEngine {
    config;
    logger;
    inference;
    constructor(config, logger, inference) {
        this.config = config;
        this.logger = logger;
        this.inference = inference;
    }
    /** Which writer will run for this request, and why. */
    mode() {
        const status = this.inference.status();
        return { mode: status.available ? 'inference' : 'knowledge', reason: status.reason ?? null };
    }
    async write(input) {
        const t1 = Date.now();
        const conversational = input.intent.intent === 'greeting' || input.intent.intent === 'capabilities';
        const hasEvidence = input.context.snippets.length > 0;
        // Conversational turns and evidence-free questions are answered from the app's
        // own voice, never by a model: there is nothing to ground them in.
        const wantsModel = this.inference.status().available && !conversational && hasEvidence;
        let answerText = '';
        let usedMode = wantsModel ? 'inference' : 'knowledge';
        let model = null;
        let inferenceNote;
        const composeInput = {
            question: input.question,
            analysis: input.analysis,
            intent: input.intent,
            memory: input.memory,
            context: input.context,
            hits: input.hits,
            coverage: input.coverage,
            corpus: input.corpus,
            mode: usedMode,
        };
        if (wantsModel) {
            try {
                const prompt = this.inference.buildPrompt({
                    question: input.question,
                    contextText: input.context.text,
                    historyTurns: input.history.slice(-4),
                    intent: input.intent.intent,
                    sourcesList: input.context.sources
                        .map((source) => `[${source.id}] ${source.path} (lines ${source.startLine}-${source.endLine})`)
                        .join('\n'),
                });
                let streamed = '';
                const result = await this.inference.generate({
                    system: prompt.system,
                    user: prompt.user,
                    maxTokens: this.config.inference.maxTokens,
                    temperature: this.config.inference.temperature,
                    signal: input.signal,
                    onDelta: (delta) => {
                        streamed += delta;
                        input.onDelta?.(delta);
                    },
                });
                answerText = result.text;
                model = result.model;
                inferenceNote = `${result.provider} · ${result.model}`;
                if (streamed.length === 0)
                    input.onDelta?.(result.text);
            }
            catch (error) {
                // A provider failure must not lose the answer: fall back to extractive.
                this.logger.warn('inference generation failed; falling back to extractive writing', { error });
                usedMode = 'knowledge';
                if (error instanceof InferenceError)
                    inferenceNote = error.message;
                const fallback = composeKnowledgeAnswer({ ...composeInput, mode: 'knowledge' });
                answerText = fallback.text;
                input.onDelta?.(fallback.text);
            }
        }
        else {
            const composed = composeKnowledgeAnswer({ ...composeInput, mode: usedMode });
            answerText = composed.text;
            input.onDelta?.(composed.text);
        }
        const composeMs = Date.now() - t1;
        /* Validation — every citation must resolve to a real retrieved passage. */
        const t2 = Date.now();
        const validation = validateAnswer({
            answer: answerText,
            snippets: input.context.snippets,
            strictQuotes: usedMode === 'inference',
        });
        answerText = validation.text;
        const report = validation.report;
        const validateMs = Date.now() - t2;
        const sources = input.context.sources.map((source) => {
            const citation = report.citations.find((entry) => entry.marker === source.id);
            return citation ? source : { ...source };
        });
        const payload = {
            id: newId('ans'),
            conversationId: input.conversationId,
            createdAt: new Date().toISOString(),
            text: answerText,
            mode: usedMode,
            intent: input.intent.intent,
            intentConfidence: input.intent.confidence,
            confidence: deriveConfidence(report, input.context.sources.length, usedMode),
            sources,
            memory: input.memory,
            validation: report,
            analysis: input.analysis,
            codeFindings: [],
            timings: { compose: composeMs, validate: validateMs },
            model,
            provenance: usedMode === 'inference'
                ? `Generated by ${inferenceNote ?? 'the configured inference provider'} from ${input.context.sources.length} retrieved passage(s); citations validated.`
                : inferenceNote
                    ? `Extractive answer composed from ${input.context.sources.length} retrieved passage(s). The model call failed (${inferenceNote}), so the extractive writer was used.`
                    : `Extractive answer composed from ${input.context.sources.length} retrieved passage(s) of the indexed repository knowledge. No language model was used.`,
        };
        return { payload, validation: report, usedMode, timings: { compose: composeMs, validate: validateMs } };
    }
}
function deriveConfidence(report, sourceCount, mode) {
    if (sourceCount === 0)
        return 'none';
    if (report.citations.length === 0)
        return 'low';
    if (mode === 'inference' && report.citationCoverage >= 0.6 && sourceCount >= 2)
        return 'high';
    if (report.citations.length >= 2 && report.passed)
        return 'high';
    if (report.passed)
        return 'medium';
    return 'low';
}
//# sourceMappingURL=answer-engine.js.map