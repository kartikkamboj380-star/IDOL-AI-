/**
 * Server-side secret storage for an optional GitHub token supplied by the
 * operator at runtime (never by the browser).
 *
 * Precedence: environment variable > encrypted file in the data directory.
 * The file is written with mode 0600 and obfuscated with a key derived from a
 * local secret file; this is defence-in-depth, not a substitute for OS-level
 * filesystem permissions. Tokens are never returned by any API endpoint.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'node:crypto';
const TOKEN_FILE = 'github-token.enc';
const KEY_FILE = 'server.key';
const CIPHER = 'aes-256-gcm';
export class SecretStore {
    dataDir;
    envToken;
    logger;
    tokenPath;
    keyPath;
    cachedToken;
    meta = null;
    constructor(dataDir, envToken, logger) {
        this.dataDir = dataDir;
        this.envToken = envToken;
        this.logger = logger;
        this.tokenPath = path.join(dataDir, TOKEN_FILE);
        this.keyPath = path.join(dataDir, KEY_FILE);
    }
    get hasEnvToken() {
        return Boolean(this.envToken);
    }
    /** True when a token is available from env or the encrypted store. */
    hasToken() {
        return Boolean(this.getToken());
    }
    getToken() {
        if (this.envToken)
            return this.envToken;
        if (this.cachedToken !== undefined)
            return this.cachedToken;
        this.cachedToken = this.readStoredToken();
        return this.cachedToken;
    }
    /** Non-secret metadata (login, scopes, save time) for the status endpoint. */
    describe() {
        if (this.envToken) {
            return { source: 'env', savedAt: null, login: this.meta?.login ?? null, scopes: this.meta?.scopes ?? null };
        }
        const stored = this.readStoredToken();
        if (stored) {
            if (!this.meta)
                this.meta = this.readMeta();
            return {
                source: 'runtime',
                savedAt: this.meta?.savedAt ?? null,
                login: this.meta?.login ?? null,
                scopes: this.meta?.scopes ?? null,
            };
        }
        return { source: 'none', savedAt: null, login: null, scopes: null };
    }
    /**
     * Persist a runtime token. Validated by the caller (GitHub /user request)
     * before this is invoked, so we only store tokens that actually work.
     */
    save(token, meta = {}) {
        if (this.envToken) {
            throw new Error('A GITHUB_TOKEN environment variable is already configured; runtime token storage is disabled.');
        }
        const trimmed = token.trim();
        if (!/^(gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{20,})$/.test(trimmed)) {
            throw new Error('That does not look like a GitHub personal access token.');
        }
        fs.mkdirSync(this.dataDir, { recursive: true });
        const key = this.loadKey();
        const iv = randomBytes(12);
        const cipher = createCipheriv(CIPHER, key, iv);
        const payload = JSON.stringify({
            token: trimmed,
            savedAt: new Date().toISOString(),
            login: meta.login,
            scopes: meta.scopes,
        });
        const encrypted = Buffer.concat([cipher.update(payload, 'utf8'), cipher.final()]);
        const tag = cipher.getAuthTag();
        const blob = Buffer.concat([iv, tag, encrypted]);
        fs.writeFileSync(this.tokenPath, blob, { mode: 0o600 });
        this.cachedToken = trimmed;
        this.meta = { savedAt: new Date().toISOString(), login: meta.login, scopes: meta.scopes };
        this.logger.info('stored runtime GitHub token', { login: meta.login ?? 'unknown' });
    }
    clear() {
        this.cachedToken = null;
        this.meta = null;
        try {
            fs.unlinkSync(this.tokenPath);
            return true;
        }
        catch {
            return false;
        }
    }
    loadKey() {
        fs.mkdirSync(this.dataDir, { recursive: true });
        try {
            const existing = fs.readFileSync(this.keyPath);
            if (existing.length >= 32)
                return existing.subarray(0, 32);
        }
        catch {
            /* generate below */
        }
        const key = randomBytes(32);
        fs.writeFileSync(this.keyPath, key, { mode: 0o600 });
        return key;
    }
    derivKey() {
        const key = this.loadKey();
        // scrypt with a static salt: the key file itself is the secret.
        return scryptSync(key, 'idol-ai-token-store', 32);
    }
    readStoredToken() {
        let blob;
        try {
            blob = fs.readFileSync(this.tokenPath);
        }
        catch {
            return null;
        }
        if (blob.length < 29)
            return null;
        try {
            const key = this.derivKey();
            const iv = blob.subarray(0, 12);
            const tag = blob.subarray(12, 28);
            const data = blob.subarray(28);
            const decipher = createDecipheriv(CIPHER, key, iv);
            decipher.setAuthTag(tag);
            const json = Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
            const parsed = JSON.parse(json);
            if (typeof parsed.token !== 'string' || parsed.token.length === 0)
                return null;
            this.meta = { savedAt: parsed.savedAt, login: parsed.login, scopes: parsed.scopes };
            return parsed.token;
        }
        catch (error) {
            this.logger.warn('stored GitHub token could not be decrypted; ignoring it', { error });
            return null;
        }
    }
    readMeta() {
        try {
            this.readStoredToken();
        }
        catch {
            /* ignore */
        }
        return this.meta;
    }
}
//# sourceMappingURL=secret-store.js.map