/**
 * Atomic JSON persistence in the server data directory.
 *
 * Writes go to a temp file in the same directory and are then renamed, so a
 * crash can never leave a half-written index behind. All reads are defensive:
 * a corrupt file is reported and treated as absent rather than crashing boot.
 */
import fs from 'node:fs';
import path from 'node:path';
export class JsonStore {
    dataDir;
    logger;
    constructor(dataDir, logger) {
        this.dataDir = dataDir;
        this.logger = logger;
        fs.mkdirSync(this.dataDir, { recursive: true });
    }
    resolve(name) {
        if (!/^[a-zA-Z0-9._-]+$/.test(name))
            throw new Error(`Unsafe store file name: ${name}`);
        return path.join(this.dataDir, name);
    }
    exists(name) {
        try {
            return fs.statSync(this.resolve(name)).isFile();
        }
        catch {
            return false;
        }
    }
    read(name, fallback) {
        const file = this.resolve(name);
        let raw;
        try {
            raw = fs.readFileSync(file, 'utf8');
        }
        catch (error) {
            if (error.code !== 'ENOENT') {
                this.logger.warn('could not read store file', { name, error });
            }
            return fallback;
        }
        try {
            return JSON.parse(raw);
        }
        catch (error) {
            this.logger.error('store file is corrupt; ignoring its contents', { name, error });
            try {
                fs.renameSync(file, `${file}.corrupt-${Date.now()}`);
            }
            catch {
                /* best effort */
            }
            return fallback;
        }
    }
    write(name, value) {
        const file = this.resolve(name);
        const tmp = `${file}.tmp-${process.pid}-${Date.now()}`;
        const payload = JSON.stringify(value);
        fs.writeFileSync(tmp, payload, { encoding: 'utf8', mode: 0o600 });
        fs.renameSync(tmp, file);
    }
    remove(name) {
        try {
            fs.unlinkSync(this.resolve(name));
        }
        catch (error) {
            if (error.code !== 'ENOENT')
                throw error;
        }
    }
    size(name) {
        try {
            return fs.statSync(this.resolve(name)).size;
        }
        catch {
            return 0;
        }
    }
}
//# sourceMappingURL=json-store.js.map