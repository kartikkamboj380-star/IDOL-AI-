/** Structured, dependency-free logger with secret redaction. */
const LEVEL_ORDER = { debug: 10, info: 20, warn: 30, error: 40 };
const SECRET_PATTERNS = [
    /gh[pousr]_[A-Za-z0-9]{16,}/g,
    /github_pat_[A-Za-z0-9_]{20,}/g,
    /sk-[A-Za-z0-9_-]{16,}/g,
    /Bearer\s+[A-Za-z0-9._-]{16,}/g,
];
export function redact(input) {
    let out = input;
    for (const pattern of SECRET_PATTERNS)
        out = out.replace(pattern, '[redacted]');
    return out;
}
function sanitizeValue(value) {
    if (typeof value === 'string')
        return redact(value);
    if (value instanceof Error) {
        return { name: value.name, message: redact(value.message) };
    }
    if (Array.isArray(value))
        return value.map(sanitizeValue);
    if (value && typeof value === 'object') {
        const out = {};
        for (const [k, v] of Object.entries(value))
            out[k] = sanitizeValue(v);
        return out;
    }
    return value;
}
export class Logger {
    scope;
    minLevel;
    json;
    constructor(scope, minLevel = 'info', json = false) {
        this.scope = scope;
        this.minLevel = minLevel;
        this.json = json;
    }
    write(level, message, fields) {
        if (LEVEL_ORDER[level] < LEVEL_ORDER[this.minLevel])
            return;
        const time = new Date().toISOString();
        const safeMessage = redact(message);
        const safeFields = fields ? sanitizeValue(fields) : undefined;
        if (this.json) {
            process.stdout.write(`${JSON.stringify({ time, level, scope: this.scope, message: safeMessage, ...safeFields })}\n`);
            return;
        }
        const suffix = safeFields && Object.keys(safeFields).length > 0 ? ` ${JSON.stringify(safeFields)}` : '';
        process.stdout.write(`${time} ${level.toUpperCase().padEnd(5)} [${this.scope}] ${safeMessage}${suffix}\n`);
    }
    debug(message, fields) {
        this.write('debug', message, fields);
    }
    info(message, fields) {
        this.write('info', message, fields);
    }
    warn(message, fields) {
        this.write('warn', message, fields);
    }
    error(message, fields) {
        this.write('error', message, fields);
    }
    child(scope) {
        return new Logger(`${this.scope}:${scope}`, this.minLevel, this.json);
    }
}
export function createLogger(nodeEnv) {
    const level = process.env.IDOL_LOG_LEVEL ?? (nodeEnv === 'production' ? 'info' : 'debug');
    return new Logger('idol', level, nodeEnv === 'production');
}
//# sourceMappingURL=logger.js.map