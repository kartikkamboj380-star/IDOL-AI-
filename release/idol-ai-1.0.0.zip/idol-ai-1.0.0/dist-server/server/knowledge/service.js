/**
 * KnowledgeService — owns knowledge sources, their indexes, and re-indexing.
 *
 * Sources are either:
 *   - `github`: a repository tree fetched through the GitHub REST API
 *   - `local` : a directory on the server filesystem (offline/self-hosted mode)
 *
 * Indexing is incremental: a content hash per file lets a re-index reuse the
 * passages of unchanged files and only fetch what actually changed. GitHub
 * tree requests use ETags so an unchanged branch costs a single 304 response.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { AppError, NotFoundError, UpstreamError, ValidationError } from '../util/errors.js';
import { mapLimit, newId, sha256, truncate } from '../util/common.js';
import { MAX_TEXT_BYTES, basename, fileFamily, parseFile, } from './file-types.js';
import { buildInvertedIndex, buildPassages, } from './indexer.js';
const SOURCES_FILE = 'sources.json';
const INDEX_VERSION = 2;
const MAX_SKIPPED_RECORDS = 120;
/** Files are ranked by how likely they are to answer documentation questions. */
function filePriority(filePath, size) {
    const lower = filePath.toLowerCase();
    const name = basename(lower);
    let score = 50;
    if (name.startsWith('readme'))
        score += 220;
    else if (lower.startsWith('docs/') || lower.includes('/docs/'))
        score += 160;
    else if (name.endsWith('.md') || name.endsWith('.mdx'))
        score += 120;
    else if (name === 'package.json' || name === 'config.json' || name.endsWith('.toml'))
        score += 60;
    else if (lower.includes('contributing') || lower.includes('architecture') || lower.includes('guide'))
        score += 90;
    else if (name === 'license')
        score += 10;
    else if (fileFamily(filePath) === 'code')
        score += 45;
    else
        score += 20;
    // Prefer top-level documentation; deep vendored paths lose.
    const depth = filePath.split('/').length - 1;
    score -= depth * 6;
    if (lower.startsWith('test/') || lower.startsWith('tests/') || lower.includes('/__tests__/'))
        score -= 25;
    if (lower.startsWith('scripts/'))
        score -= 5;
    // Tiny files rarely carry knowledge; huge files are expensive.
    if (size < 120)
        score -= 15;
    if (size > MAX_TEXT_BYTES)
        score -= 1000;
    return score;
}
function toPublicSource(source) {
    const { etag, treeSha, skipped, ...rest } = source;
    void etag;
    void treeSha;
    void skipped;
    return rest;
}
export class KnowledgeService {
    config;
    logger;
    store;
    github;
    sources = new Map();
    includeAppSources;
    indexes = new Map();
    activeJobs = new Map();
    loaded = false;
    constructor(config, logger, store, github) {
        this.config = config;
        this.logger = logger;
        this.store = store;
        this.github = github;
        // App sources (server/, web/, tests/, …) are excluded from the knowledge base by
        // default: indexing our own code makes the app answer questions about itself
        // and pollutes retrieval. Tests index them explicitly via the env flag so the
        // knowledge-mode path is exercised against real code; production never does.
        this.includeAppSources = process.env.IDOL_INDEX_APP_SOURCES === '1';
    }
    /* ------------------------------------------------------------------ */
    /* Boot                                                                */
    /* ------------------------------------------------------------------ */
    async init() {
        if (this.loaded)
            return;
        this.loaded = true;
        const file = this.store.read(SOURCES_FILE, { version: 1, sources: [] });
        for (const source of file.sources ?? []) {
            if (!source?.id)
                continue;
            const index = this.store.read(`index-${source.id}.json`, null);
            if (index && index.sourceId === source.id) {
                this.indexes.set(source.id, index);
                if (source.status === 'indexing')
                    source.status = 'ready';
            }
            else if (source.status === 'ready') {
                source.status = 'stale';
                source.lastError = 'The stored index was missing, so this source must be re-indexed.';
            }
            this.sources.set(source.id, source);
        }
        this.logger.info('loaded knowledge sources', { count: this.sources.size });
        if (this.sources.size === 0) {
            await this.bootstrap();
        }
        else {
            this.refreshLocalSources();
        }
    }
    /** First-run convenience: index the current checkout so chat works instantly. */
    async bootstrap() {
        const localRoot = this.config.localDir ?? process.cwd();
        const looksLikeRepo = await this.directoryHasRepoMarker(localRoot);
        if (looksLikeRepo) {
            try {
                const source = await this.addLocalSource(localRoot, 'This repository (local checkout)');
                this.logger.info('bootstrapped local knowledge source', { id: source.id, files: source.filesIndexed });
            }
            catch (error) {
                this.logger.warn('could not bootstrap local knowledge source', { error });
            }
        }
        const repo = this.config.defaultRepo;
        if (repo && this.github.authenticated) {
            const [owner, name] = repo.split('/');
            if (owner && name) {
                try {
                    await this.addGitHubSource({ owner, repo: name, ref: this.config.defaultRef });
                    this.logger.info('bootstrapped GitHub knowledge source', { repo });
                }
                catch (error) {
                    this.logger.warn('could not bootstrap GitHub knowledge source', { repo, error });
                }
            }
        }
        this.persistSources();
    }
    async directoryHasRepoMarker(dir) {
        try {
            const entries = await fs.readdir(dir);
            return entries.includes('.git') || entries.includes('README.md') || entries.includes('package.json');
        }
        catch {
            return false;
        }
    }
    /** Marks local sources stale when their directory changed while offline. */
    refreshLocalSources() {
        for (const source of this.sources.values()) {
            if (source.kind !== 'local')
                continue;
            if (!source.localPath)
                continue;
            void fs
                .stat(source.localPath)
                .then((stat) => {
                if (!stat.isDirectory()) {
                    source.status = 'error';
                    source.lastError = 'The local knowledge directory no longer exists.';
                }
            })
                .catch(() => {
                source.status = 'error';
                source.lastError = 'The local knowledge directory is not readable.';
            });
        }
    }
    /* ------------------------------------------------------------------ */
    /* Queries                                                             */
    /* ------------------------------------------------------------------ */
    listSources() {
        return [...this.sources.values()]
            .map(toPublicSource)
            .sort((a, b) => a.addedAt.localeCompare(b.addedAt));
    }
    getSource(id) {
        const source = this.sources.get(id);
        if (!source)
            throw new NotFoundError('That knowledge source does not exist.');
        return toPublicSource(source);
    }
    getIndex(id) {
        return this.indexes.get(id) ?? null;
    }
    /** Shape consumed by the Retriever. */
    retrieverSources() {
        const out = [];
        for (const [id, index] of this.indexes) {
            const source = this.sources.get(id);
            if (!source || source.status === 'error')
                continue;
            out.push({
                index,
                sourceName: source.name,
                htmlUrlFor: (filePath) => this.htmlUrlFor(source, index, filePath),
            });
        }
        return out;
    }
    htmlUrlFor(source, index, filePath) {
        if (source.kind === 'github' && source.owner && source.repo) {
            return `https://github.com/${source.owner}/${source.repo}/blob/${index.resolvedRef}/${filePath}`;
        }
        return source.htmlUrl ?? null;
    }
    stats() {
        let files = 0;
        let passages = 0;
        let bytes = 0;
        let ready = 0;
        let last = null;
        for (const source of this.sources.values()) {
            files += source.filesIndexed ?? 0;
            passages += source.passages ?? 0;
            bytes += source.bytesIndexed ?? 0;
            if (source.status === 'ready')
                ready += 1;
            if (source.lastIndexedAt && (!last || source.lastIndexedAt > last))
                last = source.lastIndexedAt;
        }
        return {
            totalSources: this.sources.size,
            readySources: ready,
            totalFiles: files,
            totalPassages: passages,
            totalBytes: bytes,
            lastIndexedAt: last,
        };
    }
    totalPassages() {
        let total = 0;
        for (const index of this.indexes.values())
            total += index.passages.length;
        return total;
    }
    findFile(sourceId, filePath) {
        const index = this.indexes.get(sourceId);
        if (!index)
            return null;
        return index.files.find((file) => file.path === filePath) ?? null;
    }
    /* ------------------------------------------------------------------ */
    /* Mutations                                                           */
    /* ------------------------------------------------------------------ */
    async addGitHubSource(input) {
        const owner = input.owner?.trim();
        const repo = input.repo?.trim();
        if (!owner || !repo)
            throw new ValidationError('Owner and repository name are required.');
        if (!/^[\w.-]+$/.test(owner) || !/^[\w.-]+$/.test(repo)) {
            throw new ValidationError('Owner and repository may only contain letters, numbers, dots, dashes, and underscores.');
        }
        const ref = input.ref?.trim() || null;
        const existing = [...this.sources.values()].find((source) => source.kind === 'github' && source.owner === owner && source.repo === repo && (source.ref ?? '') === (ref ?? ''));
        if (existing)
            return this.reindex(existing.id);
        const source = {
            id: newId('src'),
            kind: 'github',
            name: input.name?.trim() || `${owner}/${repo}`,
            owner,
            repo,
            ref: ref ?? undefined,
            status: 'indexing',
            addedAt: new Date().toISOString(),
            htmlUrl: `https://github.com/${owner}/${repo}`,
        };
        this.sources.set(source.id, source);
        this.persistSources();
        return this.runIndex(source);
    }
    async addLocalSource(dirPath, name) {
        const resolved = path.resolve(dirPath);
        const stat = await fs.stat(resolved).catch(() => null);
        if (!stat || !stat.isDirectory())
            throw new ValidationError('That local directory does not exist.');
        const existing = [...this.sources.values()].find((source) => source.kind === 'local' && source.localPath === resolved);
        if (existing)
            return this.reindex(existing.id);
        const source = {
            id: newId('src'),
            kind: 'local',
            name: name?.trim() || `${basename(resolved)} (local)`,
            localPath: resolved,
            status: 'indexing',
            addedAt: new Date().toISOString(),
        };
        this.sources.set(source.id, source);
        this.persistSources();
        return this.runIndex(source);
    }
    async reindex(id, options = {}) {
        const source = this.sources.get(id);
        if (!source)
            throw new NotFoundError('That knowledge source does not exist.');
        if (this.activeJobs.has(id))
            return this.activeJobs.get(id);
        const job = this.runIndex(source, options.force ?? false);
        this.activeJobs.set(id, job);
        return job;
    }
    async remove(id) {
        const source = this.sources.get(id);
        if (!source)
            throw new NotFoundError('That knowledge source does not exist.');
        this.sources.delete(id);
        this.indexes.delete(id);
        this.store.remove(`index-${id}.json`);
        this.persistSources();
        this.logger.info('removed knowledge source', { id, name: source.name });
    }
    /** Waits for all in-flight indexing jobs (used by tests and graceful shutdown). */
    async idle() {
        await Promise.allSettled([...this.activeJobs.values()]);
    }
    runIndex(source, force = false) {
        const promise = (async () => {
            const started = Date.now();
            source.status = 'indexing';
            source.lastError = undefined;
            this.persistSources();
            try {
                const index = source.kind === 'github'
                    ? await this.indexGitHub(source, force)
                    : await this.indexLocal(source);
                this.indexes.set(source.id, index);
                this.store.write(`index-${source.id}.json`, index);
                source.status = 'ready';
                source.filesIndexed = index.stats.filesIndexed;
                source.passages = index.passages.length;
                source.bytesIndexed = index.stats.bytes;
                source.skippedFiles = index.stats.skipped;
                source.truncatedTree = index.stats.truncatedTree;
                source.lastIndexedAt = new Date().toISOString();
                source.resolvedRef = index.resolvedRef;
                source.lastError = undefined;
                this.logger.info('indexed source', {
                    name: source.name,
                    files: index.stats.filesIndexed,
                    passages: index.passages.length,
                    ms: Date.now() - started,
                });
            }
            catch (error) {
                const message = error instanceof AppError ? error.message : error instanceof Error ? error.message : 'Indexing failed.';
                source.status = error instanceof AppError && error.code === 'github_rate_limited' ? 'rate_limited' : 'error';
                source.lastError = message;
                this.logger.error('indexing failed', { name: source.name, error });
                throw error;
            }
            finally {
                this.activeJobs.delete(source.id);
                this.persistSources();
            }
            return toPublicSource(source);
        })();
        return promise;
    }
    /* ------------------------------------------------------------------ */
    /* GitHub indexing                                                     */
    /* ------------------------------------------------------------------ */
    async indexGitHub(source, force) {
        const owner = source.owner;
        const repo = source.repo;
        const repoInfo = await this.github.getRepo(owner, repo);
        if (!repoInfo.data)
            throw new UpstreamError('GitHub returned no repository metadata.');
        let ref = source.ref ?? repoInfo.data.default_branch;
        let resolvedRef = ref;
        const branch = await this.github.getBranch(owner, repo, ref).catch(() => null);
        if (branch?.data?.commit?.sha) {
            resolvedRef = branch.data.commit.sha;
        }
        else {
            // `ref` may already be a commit SHA (or a tag); GitHub resolves it server-side.
            resolvedRef = ref;
        }
        source.ref = ref;
        const tree = await this.github.getTree(owner, repo, resolvedRef, force ? null : source.etag);
        if (tree.entries.length === 0 && tree.etag === source.etag) {
            const existing = this.indexes.get(source.id);
            if (existing) {
                this.logger.info('GitHub tree unchanged (304); keeping existing index', { name: source.name });
                return existing;
            }
        }
        source.etag = tree.etag;
        const previous = this.indexes.get(source.id);
        const previousFiles = new Map(previous ? previous.files.map((file) => [file.path, file]) : []);
        const previousPassages = previous ? new Map(previous.passages.map((passage) => [passage.id, passage])) : new Map();
        const candidates = this.selectGitHubFiles(tree.entries, tree.truncated);
        const previousByContent = new Map();
        for (const file of previousFiles.values()) {
            if (file.sha)
                previousByContent.set(`${file.path}:${file.sha}`, file);
        }
        const fetched = [];
        const skipped = [];
        let bytes = 0;
        const toFetch = [];
        for (const entry of candidates) {
            const priorFile = previousFiles.get(entry.path);
            if (!force && priorFile && priorFile.sha === entry.sha) {
                const passages = priorFile.passageIds
                    .map((id) => previousPassages.get(id))
                    .filter((passage) => Boolean(passage));
                if (passages.length > 0) {
                    fetched.push({
                        file: {
                            ok: true,
                            path: entry.path,
                            language: passages[0]?.language ?? 'text',
                            family: priorFile.kind === 'markdown' ? 'markdown' : priorFile.kind === 'code' ? 'code' : priorFile.kind === 'data' ? 'data' : 'text',
                            kind: priorFile.kind,
                            text: '',
                            lineCount: priorFile.lineCount,
                            truncated: priorFile.truncated,
                            title: priorFile.title,
                        },
                        sha: entry.sha,
                        size: entry.size ?? 0,
                        reusedPassages: passages,
                    });
                    bytes += entry.size ?? 0;
                    continue;
                }
            }
            toFetch.push(entry);
        }
        let fetchFailures = 0;
        await mapLimit(toFetch, this.github.authenticated ? 6 : 3, async (entry) => {
            try {
                const content = await this.github.getRawFile(owner, repo, entry.path, resolvedRef);
                const parsed = parseFile(entry.path, content, this.config.maxFileBytes);
                if (!parsed.ok) {
                    skipped.push({ path: entry.path, reason: parsed.reason });
                    return;
                }
                fetched.push({ file: parsed, sha: entry.sha, size: Buffer.byteLength(content, 'utf8') });
                bytes += Buffer.byteLength(content, 'utf8');
            }
            catch (error) {
                fetchFailures += 1;
                skipped.push({ path: entry.path, reason: error instanceof Error ? truncate(error.message, 120) : 'fetch_failed' });
            }
        });
        if (fetchFailures > 0) {
            this.logger.warn('some GitHub files could not be fetched', { name: source.name, fetchFailures });
        }
        if (fetched.length === 0) {
            throw new UpstreamError(toFetch.length === 0
                ? 'No readable text files were found in that repository (binary/asset-only repositories cannot be indexed).'
                : 'Every file fetch failed, so no knowledge could be indexed.', 'github_no_indexable_files', true);
        }
        const index = this.assembleIndex(source, resolvedRef, fetched, skipped, { truncatedTree: tree.truncated });
        return index;
    }
    selectGitHubFiles(entries, truncatedTree) {
        void truncatedTree;
        const usable = [];
        for (const entry of entries) {
            if (entry.type !== 'blob')
                continue;
            const size = entry.size ?? 0;
            if (size === 0 || size > this.config.maxFileBytes)
                continue;
            if (isSkippablePath(entry.path, { includeAppSources: this.includeAppSources }))
                continue;
            if (fileFamily(entry.path) === 'unsupported')
                continue;
            usable.push(entry);
        }
        usable.sort((a, b) => filePriority(b.path, b.size ?? 0) - filePriority(a.path, a.size ?? 0));
        let total = 0;
        const selected = [];
        for (const entry of usable) {
            if (selected.length >= this.config.maxFilesPerSource)
                break;
            if (total + (entry.size ?? 0) > this.config.maxSourceBytes)
                continue;
            total += entry.size ?? 0;
            selected.push(entry);
        }
        return selected;
    }
    /* ------------------------------------------------------------------ */
    /* Local indexing                                                      */
    /* ------------------------------------------------------------------ */
    async indexLocal(source) {
        const root = source.localPath;
        if (!root)
            throw new ValidationError('This local source has no directory.');
        const candidates = await this.walkDirectory(root);
        const previous = this.indexes.get(source.id);
        const previousByPath = new Map(previous?.files.map((file) => [file.path, file]) ?? []);
        const previousPassages = new Map(previous?.passages.map((passage) => [passage.id, passage]) ?? []);
        const fetched = [];
        const skipped = [];
        let bytes = 0;
        for (const relativePath of candidates) {
            const absolute = path.join(root, relativePath);
            let stat;
            try {
                stat = await fs.stat(absolute);
            }
            catch {
                continue;
            }
            if (!stat.isFile() || stat.size === 0 || stat.size > this.config.maxFileBytes)
                continue;
            if (isSkippablePath(relativePath, { includeAppSources: this.includeAppSources }))
                continue;
            if (fileFamily(relativePath) === 'unsupported')
                continue;
            let content;
            try {
                content = await fs.readFile(absolute, 'utf8');
            }
            catch {
                skipped.push({ path: relativePath, reason: 'unreadable' });
                continue;
            }
            const digest = sha256(content);
            const prior = previousByPath.get(relativePath);
            if (prior && prior.sha === digest) {
                const passages = prior.passageIds
                    .map((id) => previousPassages.get(id))
                    .filter((passage) => Boolean(passage));
                if (passages.length > 0) {
                    fetched.push({
                        file: {
                            ok: true,
                            path: relativePath,
                            language: passages[0]?.language ?? 'text',
                            family: prior.kind === 'markdown' ? 'markdown' : prior.kind === 'code' ? 'code' : prior.kind === 'data' ? 'data' : 'text',
                            kind: prior.kind,
                            text: '',
                            lineCount: prior.lineCount,
                            truncated: prior.truncated,
                            title: prior.title,
                        },
                        sha: digest,
                        size: stat.size,
                        reusedPassages: passages,
                    });
                    bytes += stat.size;
                    continue;
                }
            }
            const parsed = parseFile(relativePath, content, this.config.maxFileBytes);
            if (!parsed.ok) {
                skipped.push({ path: relativePath, reason: parsed.reason });
                continue;
            }
            fetched.push({ file: parsed, sha: digest, size: stat.size });
            bytes += stat.size;
            if (fetched.length >= this.config.maxFilesPerSource)
                break;
        }
        if (fetched.length === 0) {
            throw new UpstreamError('No readable text files were found in that directory.', 'local_no_files', false);
        }
        return this.assembleIndex(source, 'local', fetched, skipped, { truncatedTree: false });
    }
    async walkDirectory(root) {
        const out = [];
        const queue = [''];
        const skipDirs = new Set([
            '.git', 'node_modules', 'dist', 'dist-server', 'build', '.data', '.next', 'coverage',
            '__pycache__', '.venv', 'venv', '.cache', 'vendor', '.idea', '.vscode', 'target', 'out',
        ]);
        let scanned = 0;
        while (queue.length > 0 && out.length < this.config.maxFilesPerSource * 3) {
            const current = queue.shift();
            let entries;
            try {
                entries = await fs.readdir(path.join(root, current), { withFileTypes: true });
            }
            catch {
                continue;
            }
            for (const entry of entries) {
                scanned += 1;
                if (scanned > this.config.maxTreeEntries * 4)
                    break;
                const rel = current ? `${current}/${entry.name}` : entry.name;
                if (entry.isDirectory()) {
                    if (skipDirs.has(entry.name) || entry.name.startsWith('.'))
                        continue;
                    queue.push(rel);
                }
                else if (entry.isFile()) {
                    if (entry.name.startsWith('.') && !['.gitattributes', '.gitignore', '.env.example'].includes(entry.name))
                        continue;
                    out.push(rel);
                }
            }
        }
        out.sort((a, b) => filePriority(b, 1000) - filePriority(a, 1000));
        return out;
    }
    /* ------------------------------------------------------------------ */
    /* Assembly                                                            */
    /* ------------------------------------------------------------------ */
    assembleIndex(source, resolvedRef, fetched, skipped, meta) {
        const files = [];
        const passages = [];
        let truncatedFiles = 0;
        let bytes = 0;
        for (const item of fetched) {
            const remaining = this.config.maxChunksPerSource - passages.length;
            if (remaining <= 0)
                break;
            let filePassages;
            if (item.reusedPassages && item.reusedPassages.length > 0) {
                filePassages = item.reusedPassages;
            }
            else {
                filePassages = buildPassages(source.id, item.file, null, { maxChunks: remaining });
                if (item.file.truncated)
                    truncatedFiles += 1;
            }
            const limited = filePassages.slice(0, remaining);
            passages.push(...limited);
            const kind = item.file.kind;
            files.push({
                path: item.file.path,
                size: item.size,
                sha: item.sha,
                language: item.file.language,
                kind,
                lineCount: item.file.lineCount,
                passageIds: limited.map((passage) => passage.id),
                title: item.file.title,
                truncated: item.file.truncated,
                htmlUrl: source.kind === 'github' && source.owner && source.repo
                    ? `https://github.com/${source.owner}/${source.repo}/blob/${resolvedRef}/${item.file.path}`
                    : null,
            });
            bytes += item.size;
        }
        const { postings, docFreq, avgLength, totalLength } = buildInvertedIndex(source.id, files, passages);
        source.skipped = skipped.slice(0, MAX_SKIPPED_RECORDS);
        source.treeSha = resolvedRef;
        return {
            sourceId: source.id,
            builtAt: new Date().toISOString(),
            ref: source.ref ?? resolvedRef,
            resolvedRef,
            files,
            passages,
            postings,
            docFreq,
            avgLength,
            totalLength,
            stats: {
                filesIndexed: files.length,
                passages: passages.length,
                bytes,
                skipped: skipped.length,
                truncatedTree: meta.truncatedTree,
                truncatedFiles,
            },
        };
    }
    /* ------------------------------------------------------------------ */
    /* Browsing                                                            */
    /* ------------------------------------------------------------------ */
    async listDirectory(sourceId, dirPath) {
        const index = this.indexes.get(sourceId);
        const source = this.sources.get(sourceId);
        if (!source)
            throw new NotFoundError('That knowledge source does not exist.');
        if (!index)
            throw new UpstreamError('This source has no index yet. Re-index it first.', 'no_index', true);
        const normalized = dirPath.replace(/^\/+|\/+$/g, '');
        const prefix = normalized ? `${normalized}/` : '';
        const seen = new Set();
        const entries = [];
        for (const file of index.files) {
            if (!file.path.startsWith(prefix))
                continue;
            const rest = file.path.slice(prefix.length);
            const slash = rest.indexOf('/');
            if (slash === -1) {
                if (seen.has(rest))
                    continue;
                seen.add(rest);
                entries.push({ path: file.path, type: 'file', size: file.size });
            }
            else {
                const dir = rest.slice(0, slash);
                if (seen.has(dir))
                    continue;
                seen.add(dir);
                entries.push({ path: `${prefix}${dir}`, type: 'dir' });
            }
        }
        entries.sort((a, b) => (a.type === b.type ? a.path.localeCompare(b.path) : a.type === 'dir' ? -1 : 1));
        return { entries: entries.slice(0, 500), truncated: entries.length > 500 };
    }
    /** Returns stored index metadata for a file (no network needed). */
    async readFile(sourceId, filePath) {
        const source = this.sources.get(sourceId);
        const index = this.indexes.get(sourceId);
        if (!source)
            throw new NotFoundError('That knowledge source does not exist.');
        if (!index)
            throw new UpstreamError('This source has no index yet.', 'no_index', true);
        const file = index.files.find((entry) => entry.path === filePath);
        if (!file)
            throw new NotFoundError('That file is not part of the indexed knowledge.');
        if (source.kind === 'github' && source.owner && source.repo) {
            const content = await this.github.getRawFile(source.owner, source.repo, filePath, index.resolvedRef);
            const limited = content.length > this.config.maxFileBytes ? content.slice(0, this.config.maxFileBytes) : content;
            return {
                content: limited,
                language: file.language,
                kind: file.kind,
                size: Buffer.byteLength(content, 'utf8'),
                htmlUrl: file.htmlUrl,
                truncated: content.length > this.config.maxFileBytes,
            };
        }
        if (!source.localPath)
            throw new NotFoundError('This source has no readable directory.');
        const absolute = path.resolve(source.localPath, filePath);
        if (!absolute.startsWith(path.resolve(source.localPath))) {
            throw new ValidationError('Invalid file path.');
        }
        const content = await fs.readFile(absolute, 'utf8').catch(() => null);
        if (content === null)
            throw new NotFoundError('That file could not be read from the local directory.');
        return {
            content: content.slice(0, this.config.maxFileBytes),
            language: file.language,
            kind: file.kind,
            size: Buffer.byteLength(content, 'utf8'),
            htmlUrl: file.htmlUrl,
            truncated: content.length > this.config.maxFileBytes,
        };
    }
    persistSources() {
        const payload = {
            version: 1,
            sources: [...this.sources.values()],
        };
        try {
            this.store.write(SOURCES_FILE, payload);
        }
        catch (error) {
            this.logger.error('could not persist knowledge sources', { error });
        }
    }
}
const SKIP_PATH_PARTS = [
    'node_modules/', '/node_modules/', 'dist/', 'dist-server/', 'build/', 'coverage/',
    '__pycache__/', '.git/', '/vendor/', 'package-lock.json', 'pnpm-lock.yaml', 'yarn.lock',
];
/**
 * The assistant's own implementation. Indexing it would let the retriever match
 * its own source (sample questions, vocabulary lists, error strings) instead of
 * the user's documentation. Operators can opt in with IDOL_INDEX_APP_SOURCES=1.
 */
const APP_SOURCE_PREFIXES = ['server/', 'web/', 'shared/', 'tests/', 'scripts/', 'data/'];
export function isSkippablePath(filePath, options = {}) {
    const lower = filePath.toLowerCase();
    if (SKIP_PATH_PARTS.some((part) => lower.startsWith(part) || lower.includes(`/${part}`)))
        return true;
    if (options.includeAppSources === true)
        return false;
    if (APP_SOURCE_PREFIXES.some((prefix) => lower === prefix.slice(0, -1) || lower.startsWith(prefix)))
        return true;
    if (lower.endsWith('tsconfig.json') || lower.startsWith('tsconfig') || lower === 'vite.config.ts')
        return true;
    return false;
}
export { INDEX_VERSION };
export { SOURCES_FILE };
//# sourceMappingURL=service.js.map