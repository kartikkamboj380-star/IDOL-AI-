import { PayloadTooLargeError, ValidationError } from '../util/errors.js';
/**
 * Strict CSP for the SPA. The UI ships no third-party scripts; code
 * highlighting and markdown rendering happen locally from bundled modules.
 */
export function securityHeaders(isDev) {
    return (req, res, next) => {
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('Referrer-Policy', 'no-referrer');
        res.setHeader('X-Frame-Options', 'SAMEORIGIN');
        res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
        res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
        const csp = [
            "default-src 'self'",
            // Vite dev mode injects inline scripts for HMR; production uses files only.
            `script-src 'self'${isDev ? " 'unsafe-inline' 'unsafe-eval'" : ''}`,
            "style-src 'self' 'unsafe-inline'",
            "img-src 'self' data: blob: https://github.com https://avatars.githubusercontent.com",
            "font-src 'self' data:",
            "connect-src 'self'" + (isDev ? ' ws: wss:' : ''),
            "object-src 'none'",
            "base-uri 'self'",
            "form-action 'self'",
            "frame-ancestors 'none'",
        ].join('; ');
        res.setHeader('Content-Security-Policy', csp);
        if (req.path.startsWith('/api/')) {
            res.setHeader('Cache-Control', 'no-store');
        }
        next();
    };
}
export function requireJsonBody(req) {
    const body = req.body;
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
        throw new ValidationError('Expected a JSON object body.');
    }
    return body;
}
export function readString(body, key, options = {}) {
    const raw = body[key];
    if (raw === undefined || raw === null) {
        if (options.required)
            throw new ValidationError(`Field "${key}" is required.`);
        return undefined;
    }
    if (typeof raw !== 'string')
        throw new ValidationError(`Field "${key}" must be a string.`);
    const value = options.trim === false ? raw : raw.trim();
    if (options.required && value.length === 0)
        throw new ValidationError(`Field "${key}" must not be empty.`);
    if (options.minLength !== undefined && value.length > 0 && value.length < options.minLength) {
        throw new ValidationError(`Field "${key}" must be at least ${options.minLength} characters.`);
    }
    if (options.maxLength !== undefined && value.length > options.maxLength) {
        throw new PayloadTooLargeError(`Field "${key}" is ${value.length} characters, over the ${options.maxLength}-character limit.`);
    }
    return value;
}
export function readStringArray(body, key, maxItems = 20) {
    const raw = body[key];
    if (raw === undefined || raw === null)
        return undefined;
    if (!Array.isArray(raw))
        throw new ValidationError(`Field "${key}" must be an array of strings.`);
    const values = raw.filter((item) => typeof item === 'string').map((item) => item.trim()).filter(Boolean);
    if (values.length > maxItems)
        throw new ValidationError(`Field "${key}" may contain at most ${maxItems} items.`);
    return values;
}
export function readHistory(body, maxTurns, maxChars) {
    const raw = body.history;
    if (raw === undefined || raw === null)
        return [];
    if (!Array.isArray(raw))
        throw new ValidationError('Field "history" must be an array.');
    const turns = [];
    for (const item of raw) {
        if (!item || typeof item !== 'object')
            continue;
        const record = item;
        const role = record.role;
        const content = record.content;
        if (role !== 'user' && role !== 'assistant')
            continue;
        if (typeof content !== 'string' || content.trim().length === 0)
            continue;
        turns.push({ role, content: content.slice(0, maxChars) });
    }
    // Context-window management: keep the most recent turns and cap total chars.
    const recent = turns.slice(-maxTurns);
    const budget = maxChars * 4;
    let used = 0;
    const kept = [];
    for (let i = recent.length - 1; i >= 0; i -= 1) {
        const turn = recent[i];
        if (used + turn.content.length > budget)
            break;
        used += turn.content.length;
        kept.unshift(turn);
    }
    return kept;
}
/** Detects whether the request is HTTPS or behind a trusted proxy. */
export function isSecureRequest(req) {
    if (req.secure)
        return true;
    const proto = req.headers['x-forwarded-proto'];
    const value = Array.isArray(proto) ? proto[0] : proto;
    return value === 'https';
}
//# sourceMappingURL=security.js.map